import type { Interests, Profile_Interests } from '../types/bobType';
import { supabase } from './supabase';

// 추천 관심사
export const fetchInterests = async (): Promise<Interests[]> => {
  const { data, error } = await supabase
    .from('interests')
    .select('*')
    .order('category', { ascending: true })
    .order('name', { ascending: true });

  if (error) throw error;
  return data ?? [];
};

// 관심사 그룹
export const fetchInterestsGrouped = async (): Promise<Record<string, string[]>> => {
  const rows = await fetchInterests();
  return rows.reduce<Record<string, string[]>>((accumulator, current) => {
    (accumulator[current.category] ??= []).push(current.name);
    return accumulator;
  }, {});
};

// 사용자 관심사 조회
export const fetchProfileInterests = async (ProfileId: string): Promise<Interests[]> => {
  const { data, error } = await supabase
    .from('profile_interests')
    .select('interest_id, interests(name)')
    .eq('profile_id', ProfileId);

  if (error) throw error;

  const resultarr = data.map(row => row.interests.name as string);

  return data?.map(row => row.interests?.name).filter(Boolean) ?? [];
};
