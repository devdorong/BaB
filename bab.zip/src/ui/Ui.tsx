export const LogoSm = () => {
  return <img src="/images/logo_sm.png" />;
};

export const LogoMd = () => {
  return <img src="/images/logo_md.png" />;
};

export const LogoLg = () => {
  return <img src="/images/logo_lg.png" />;
};
