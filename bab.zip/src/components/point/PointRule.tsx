import React from 'react';

const PointRule = () => {
  return <div>PointRule</div>;
};

export default PointRule;
