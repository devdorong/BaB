function AdminMatchingPage() {
  return <div>AdminMatchingPage</div>;
}

export default AdminMatchingPage;
