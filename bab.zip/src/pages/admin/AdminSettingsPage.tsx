function AdminSettingsPage() {
  return <div>AdminSettingsPage</div>;
}

export default AdminSettingsPage;
