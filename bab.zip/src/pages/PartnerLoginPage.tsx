function PartnerLoginPage() {
  return <div>PartnerLoginPage</div>;
}

export default PartnerLoginPage;
