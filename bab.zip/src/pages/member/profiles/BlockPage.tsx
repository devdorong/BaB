function BlockPage() {
  return <div>BlockPage</div>;
}

export default BlockPage;
