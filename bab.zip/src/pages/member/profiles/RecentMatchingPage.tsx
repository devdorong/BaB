function RecentMatchingPage() {
  return <div>RecentMatchingPage</div>;
}

export default RecentMatchingPage;
