function FavoritePage() {
  return <div>FavoritePage</div>;
}

export default FavoritePage;
