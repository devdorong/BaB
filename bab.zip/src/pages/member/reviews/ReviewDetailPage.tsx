function ReviewDetailPage() {
  return <div>ReviewDetailPage</div>;
}

export default ReviewDetailPage;
