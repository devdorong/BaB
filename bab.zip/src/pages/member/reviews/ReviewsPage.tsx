function ReviewsPage() {
  return (
    <div>
      <h2>ReviewsPage</h2>
    </div>
  );
}

export default ReviewsPage;
