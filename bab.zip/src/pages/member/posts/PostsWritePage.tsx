function PostsWritePage() {
  return <div>PostsWritePage</div>;
}

export default PostsWritePage;
