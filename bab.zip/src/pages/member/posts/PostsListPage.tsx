function PostsListPage() {
  return (
    <div>
      <h2>PostListPage</h2>
    </div>
  );
}

export default PostsListPage;
