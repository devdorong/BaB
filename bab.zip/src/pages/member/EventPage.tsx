function EventPage() {
  return <div>EventPage</div>;
}

export default EventPage;
