function KaKaoPage() {
  return <div>KaKaoPage</div>;
}

export default KaKaoPage;
