function SettingsPage() {
  return <div>SettingsPage</div>;
}

export default SettingsPage;
