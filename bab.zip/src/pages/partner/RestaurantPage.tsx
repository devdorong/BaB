function RestaurantPage() {
  return <div>RestaurantPage</div>;
}

export default RestaurantPage;
