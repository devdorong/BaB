function SalesPage() {
  return <div>SalesPage</div>;
}

export default SalesPage;
