function PartnerSignupPage() {
  return <div>PartnerSignupPage</div>;
}

export default PartnerSignupPage;
