function NotificationPage() {
  return <div>NotificationPage</div>;
}

export default NotificationPage;
