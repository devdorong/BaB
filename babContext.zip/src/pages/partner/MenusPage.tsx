function MenusPage() {
  return <div>MenusPage</div>;
}

export default MenusPage;
