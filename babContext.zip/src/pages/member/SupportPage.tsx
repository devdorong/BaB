function SupportPage() {
  return <div>SupportPage</div>;
}

export default SupportPage;
