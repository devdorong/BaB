import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../../../contexts/AuthContext';
import { GetPoint } from '../../../services/babService';
import type { Profile } from '../../../types/bobType';
import { usePoint } from '../../../contexts/BabContext';

function PointPage() {
  const { user } = useAuth();
  const navigate = useNavigate();

  const { loading, point, refreshPoint } = usePoint();

  // 포인트 정보 불러오기
  useEffect(() => {
    if (!user) return;
    refreshPoint();
  }, [user, refreshPoint]);

  if (loading) return <p>포인트 불러오는 중..</p>;

  return (
    <div>
      <p>야 포인트ㅐ놔</p>
      <h3>{point}</h3>
    </div>
  );
}

export default PointPage;
