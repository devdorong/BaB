function ChatPage() {
  return <div>ChatPage</div>;
}

export default ChatPage;
