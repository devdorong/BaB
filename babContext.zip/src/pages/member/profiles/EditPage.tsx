function EditPage() {
  return <div>EditPage</div>;
}

export default EditPage;
