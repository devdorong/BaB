function InterestPage() {
  return <div>InterestPage</div>;
}

export default InterestPage;
