function PostDetailPage() {
  return <div>PostDetailPage</div>;
}

export default PostDetailPage;
