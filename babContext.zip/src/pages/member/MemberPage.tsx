import { useState } from 'react';
import { ButtonFillLG, ButtonFillMd, ButtonLineLg, ButtonLineMd } from '../../ui/button';
import { LogoLg, LogoMd, LogoSm } from '../../ui/Ui';

function MemberPage() {
  return (
    <div>
      <h2>MemberPage</h2>
    </div>
  );
}

export default MemberPage;
