function CommunityDetailPage() {
  return <div>CommunityDetailPage</div>;
}

export default CommunityDetailPage;
