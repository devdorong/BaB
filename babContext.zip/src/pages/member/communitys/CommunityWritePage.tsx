function CommunityWritePage() {
  return <div>CommunityWritePage</div>;
}

export default CommunityWritePage;
