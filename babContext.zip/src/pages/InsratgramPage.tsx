function InsratgramPage() {
  return <div>InsratgramPage</div>;
}

export default InsratgramPage;
