function PartnerPage() {
  return <div>PartnerPage</div>;
}

export default PartnerPage;
