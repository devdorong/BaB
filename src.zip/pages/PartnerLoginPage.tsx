import { RiCheckboxCircleLine, RiLock2Line, RiUserLine } from 'react-icons/ri';
import { LogoLg, PartnerLogo } from '../ui/Ui';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { useState } from 'react';
import { GoogleIconSvg, KakaoIconSvg } from '../ui/jy/IconSvg';
import type { Profile } from '../types/bobType';
import { getProfile } from '../lib/propile';
import { supabase } from '../lib/supabase';
import GoogleLoginButton from '../components/GoogleLoginButton';
import GoogleLoginSmallButton from '../components/GoogleLoginSmallButton';
import KakaoLoginSmallButton from '../components/KakaoLoginSmallButton';

function PartnerLoginPage() {
  const navigate = useNavigate();
  const { signIn } = useAuth();
  const [email, setEmail] = useState('');
  const [pw, setPw] = useState('');
  const [msg, setMsg] = useState('');
  const [profileData, setProfileData] = useState<Profile | null>(null);
  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const { error } = await signIn(email, pw);
    if (error) {
      setMsg(`로그인 오류 : ${error}`);
    }
    const tempData = await getProfile(await supabase.auth.getUser().then(r => r.data.user?.id!));
    if (!tempData) {
      setMsg('프로필 없음');
      return;
    }
    setProfileData(tempData);
    if (tempData.role === 'partner' || tempData.role === 'admin') {
      navigate('/partner');
    } else {
      if (confirm('파트너만 이용가능합니다. 파트너 신청 하시겠습니까?')) {
        navigate('/partner/signup');
      } else {
        alert('멤버페이지로 이동합니다.');
        navigate('/member');
      }
    }
  };

  return (
    <div className="flex flex-col items-center bg-bg-bg h-screen justify-center">
      <div className="pb-[52px]">
        <PartnerLogo />
      </div>
      <div className="flex flex-col">
        <form onSubmit={handleSubmit}>
          <div className="inline-flex flex-col justify-start items-start ">
            <div className="flex flex-col gap-7">
              {/* 아이디 */}
              <div className="self-stretch w-[450px] h-[45px] px-3.5 py-3 bg-white rounded-3xl outline outline-1 outline-offset-[-1px] outline-babgray-300 inline-flex justify-start items-center text-center gap-2">
                <RiUserLine className="text-babgray-300" />
                <input
                  type="email"
                  value={email}
                  onChange={e => setEmail(e.target.value)}
                  placeholder="아이디"
                  required
                  className="flex-1 text-babgray-700 outline-none text-[16px] items-center "
                />
              </div>
              {/* 비밀번호 */}
              <div className="self-stretch w-[450px] h-[45px] px-3.5 py-3 bg-white rounded-3xl outline outline-1 outline-offset-[-1px] outline-babgray-300 inline-flex justify-start items-center text-center gap-2">
                <RiLock2Line className="text-babgray-300" />
                <input
                  type="password"
                  value={pw}
                  onChange={e => setPw(e.target.value)}
                  placeholder="비밀번호"
                  required
                  className="flex-1 text-babgray-700 outline-none text-[16px] items-center "
                />
              </div>
            </div>

            {/* 로그인 상태유지 */}

            <label className="inline-flex items-center gap-1 pt-[25px] cursor-pointer">
              <input
                type="checkbox"
                className="peer hidden" // 기본 체크박스 숨김
              />
              <RiCheckboxCircleLine
                className="text-xl text-babgray-600 
               peer-checked:text-white peer-checked:bg-babgray-600 
               rounded-full transition-colors"
              />
              <span className="justify-start text-babgray-900 text-base font-normal">
                로그인 상태 유지
              </span>
            </label>
            {/* 로그인 버튼 */}
            <div className="py-[28px]">
              <button
                type="submit"
                className="px-[15px] w-[450px] h-[50px] self-stretch bg-babgray-800 rounded-lg inline-flex justify-center items-center hover:bg-babgray-600"
              >
                <div className="justify-start text-white text-base font-semibold">로그인</div>
              </button>
            </div>
          </div>
        </form>

        {/* 아이디/비밀번호 찾기/회원가입 */}
        <div className="flex gap-2 justify-center pb-[28px]">
          <div className="text-center justify-start text-babgray-500 text-base font-medium">
            아이디 찾기
          </div>
          <div className="text-center justify-start text-babgray-500 text-base font-medium">|</div>
          <div className="text-center justify-start text-babgray-500 text-base font-medium">
            비밀번호 찾기
          </div>
          <div className="text-center justify-start text-babgray-500 text-base font-medium">|</div>
          <div
            onClick={() => navigate('/partner/signup')}
            className="text-center justify-start text-babgray-500 text-base font-medium cursor-pointer"
          >
            파트너 신청하기
          </div>
        </div>
        {/* 소셜 로그인 아이콘 */}
        <div className="flex gap-[24px] justify-center">
          <GoogleLoginSmallButton
            onError={error => setMsg(`구글 로그인 오류 : ${error}`)}
            onSuccess={message => setMsg(message)}
          />

          <KakaoLoginSmallButton onError={error => setMsg(`카카오 로그인 오류 : ${error}`)} />
        </div>
      </div>
    </div>
  );
}

export default PartnerLoginPage;
