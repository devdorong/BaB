function AdminReportsPage() {
  return <div>AdminReportsPage</div>;
}

export default AdminReportsPage;
