function AdminPartnersPage() {
  return <div>AdminPartnersPage</div>;
}

export default AdminPartnersPage;
