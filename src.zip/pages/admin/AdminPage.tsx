function AdminPage() {
  return <div>AdminPage</div>;
}

export default AdminPage;
