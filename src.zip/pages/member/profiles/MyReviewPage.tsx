import React, { useEffect, useState } from 'react';
import { BrandTag, GrayTag } from '../../../ui/tag';
import RestaurantCard from '../../../ui/jy/RestaurantCard';
import { useNavigate } from 'react-router-dom';
import { fetchMyReviewData, type MyReviewData } from '../../../lib/myreviews';
import { supabase } from '../../../lib/supabase';
import MyreviewCard from '../../../ui/jy/MyReviewCard';
import { categoryColors, defaultCategoryColor } from '../../../ui/jy/categoryColors';

function MyReviewPage({ restaurantId }: { restaurantId: number }) {
  const navigate = useNavigate();
  const [review, setReview] = useState<MyReviewData[]>([]);
  const [loading, setLoading] = useState<boolean>(false);

  useEffect(() => {
    const loadReview = async () => {
      setLoading(true);
      try {
        const data = await fetchMyReviewData();
        console.log(data);
        setReview(data);
      } catch (error) {
        console.log(error);
      } finally {
        setLoading(false);
      }
    };
    loadReview();
  }, []);

  return (
    <div id="root" className="flex flex-col min-h-screen">
      <div className="w-[1280px] mx-auto">
        {/* 프로필 헤더 링크 */}
        <div className="flex py-[15px]">
          <div
            onClick={() => navigate('/member/profile')}
            className="text-babgray-600 text-[17px] cursor-pointer hover:text-babgray-900"
          >
            프로필
          </div>
          <div className="text-babgray-600 px-[5px] text-[17px]">{'>'}</div>
          <div className="text-bab-500 text-[17px]">내가 쓴 리뷰</div>
        </div>
        <div className="w-[1280px] mx-auto flex flex-col gap-8 py-8">
          {/* 타이틀 */}
          <div className="flex flex-col gap-1 pb-[30px]">
            <p className="text-3xl font-bold">내가 쓴 리뷰</p>
          </div>

          <div className="grid grid-cols-4 gap-6">
            {review.map(r => {
              const reviewCount = r.restaurants?.reviews?.[0]?.count ?? 0;
              const category = r.restaurants?.restaurants_category_id_fkey?.name ?? '';
              const color = categoryColors[category] || defaultCategoryColor;
              const favoriteCount = r.restaurants?.favorite ?? 0;
              return (
                <MyreviewCard
                  key={r.review_id}
                  imageUrl={r.restaurants?.thumbnail_url || ''}
                  name={r.restaurants?.name || ''}
                  rating={r.rating_food}
                  reviewCount={`리뷰 ${reviewCount}개`}
                  comment={r.comment}
                  category={category}
                  tagBg={color.bg}
                  tagText={color.text}
                />
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
}

export default MyReviewPage;
