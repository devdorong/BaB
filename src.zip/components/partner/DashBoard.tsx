const DashBoard = () => {
  return <div>DashBoard</div>;
};

export default DashBoard;
